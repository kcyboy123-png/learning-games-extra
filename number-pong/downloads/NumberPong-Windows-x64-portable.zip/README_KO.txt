번호퐁 · 햄찌 / 펭귄 / 당근

1. ZIP 파일을 먼저 '모두 압축 풀기'로 풀어 주세요.
2. 풀린 폴더의 NumberPongHost.exe를 실행하세요.
3. DLL 파일과 public 폴더는 실행파일과 함께 두세요. EXE만 옮기면 실행되지 않습니다.

Windows 64비트(x64)용 프로그램입니다.
Microsoft Edge WebView2 Runtime이 설치되어 있어야 합니다.
Runtime이 없는 경우 인터넷 연결 상태에서 Microsoft 공식 배포 페이지에서 설치해 주세요.
https://developer.microsoft.com/microsoft-edge/webview2/
실행 환경이 준비된 뒤에는 인터넷 없이 번호를 뽑을 수 있습니다.

번호 입력 후 발사 버튼 또는 스페이스 키를 누르세요.
테마를 바꾸어도 같은 추첨 기록이 유지됩니다.
공개 웹사이트와 이 실행파일의 추첨 기록은 서로 별도입니다.
데이터 위치: %LOCALAPPDATA%\Changyong\AnimalNumberPong\BrowserData

이 프로그램은 디지털 서명되지 않았습니다. 학교 보안 정책에 따라 실행이 제한될 수 있습니다.
실행이 제한되면 학교의 허용 절차를 확인하거나 웹 버전을 이용해 주세요.
